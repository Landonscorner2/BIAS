#!/bin/bash

echo "BIAS - Bias Isn't A Shell!"

while true; do

        read -p ">: " userin

        case $userin in
                "help") echo "e - exit command line. f - lists home directory. rf - lists root directory. ctxt - creates text file with user inputted words. c - clears the screen. p - shows the contents of any text file the user inputs." ;;
                "e") exit ;;
                "f") ls ;;
                "rf") ls / ;;
                "ctxt") read -p "?: " utext
                echo "$utext" >> file.txt ;;
                "ver") echo "bias 0.0.1" ;;
                "c") clear ;;
                "p") read -p "?: " printusertext
                cat "$printusertext" ;;
                *) echo "Unknown Command.";;
        esac
done           
